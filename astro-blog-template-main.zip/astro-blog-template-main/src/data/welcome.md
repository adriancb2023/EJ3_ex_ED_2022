---
title: "Welcome to Astro"
slug: "welcome-to-astro"
date: 2020-02-25
description: "You’ll find this post in your `post` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `npm start`, which launches a web server and"
tags:
  - astro
---

You’ll find this post in your `post` directory. Go ahead and edit it and re-build the site to see your changes. You can rebuild the site in many different ways, but the most common way is to run `npm start`, which launches a web server and
auto-regenerates your site when a file is updated.

To add new posts, simply add a file in the `posts` directory that includes the necessary front matter. Take a look at the source for this post to get an idea about how it works.

Check out the [Astro docs][astro-docs] for more info on how to get the most out of Jekyll. File all bugs/feature requests at [Astro GitHub repo][astro-gh].

[astro-docs]: https://docs.astro.build
[astro-gh]: https://github.com/withastro/astro
